The file contains 3 different type of algorithm implementations.

1. Backtracking algorithm
2. Minimum Conflict algorithm
3. Minimum Conflict with Backtracking algorithm

Each directly contains driver, header and makefile.
To Compile the code, run the makefile and it'll create a executable file called main.
To compile the code:  make
Upon execution, it will search through a grid to find a solution
to N-Queen problem. The program will display the result grid and execution time.
To execute the file main file:  ./main

You could also change the number of Queens in Queen.h file in each directly.
